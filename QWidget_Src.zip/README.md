ClassicPress/Wordpress-Plugin with widgets:

QCompany:   Microdata (RDF/a) friendly company address

--- THIS IS UNFINISHED SOFTWARE ---
