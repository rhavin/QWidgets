<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
	<head>
		<meta charset="UTF-8">
		<title>TEST</title>
	</head>
	<body>
		<?php
		phpinfo();
		?>
	</body>
</html>
