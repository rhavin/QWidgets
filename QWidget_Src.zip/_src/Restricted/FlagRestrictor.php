<?php
namespace Q\Restricted;

/**
 * Description of FlagRestrictor
 *
 * @author rhavin
 */
class FlagRestrictor implements Restrictor {
	private int $my_flags = 0;
	public function __construct(int $flags = 0) {
		$this->my_flags = $flags;
	}
	public function isDenied(mixed $access): bool {
		return ($this->my_flags & $access > 0);
	}

	public function isDeniedCreate(): bool {
		return (($this->my_flags & Restrictor::DENY_CREATE) > 0);
	}

	public function isDeniedDelete(): bool {
		return (($this->my_flags & Restrictor::DENY_DELETE) > 0);
	}

	public function isDeniedRead(): bool {
		return (($this->my_flags & Restrictor::DENY_READ) > 0);
	}

	public function isDeniedRestrictor(): bool {
		return (($this->my_flags & Restrictor::DENY_RESTRICT) > 0);
	}

	public function isDeniedWrite(): bool {
		return (($this->my_flags & Restrictor::DENY_WRITE) > 0);
	}
	public function setAccess(mixed $access) : bool {
		if ($this->my_flags & Restrictor::DENY_RESTRICT)
			return false;
		$this->my_flags = $access;
		return true;
	}
	public function denyAccess(mixed $access) : bool {
		if ($this->my_flags & Restrictor::DENY_RESTRICT)
			return false;
		$this->my_flags |= $access;
		return true;
	}
	public function allowAccess(mixed  $access) : bool {
		if ($this->my_flags & Restrictor::DENY_RESTRICT)
			return false;
		$this->my_flags &= ~$access;
		return true;
	}
	public function getAccess() : int {
		return $this->my_flags;
	}

}
