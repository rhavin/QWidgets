<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Q\Schema;

/**
 * Description of StringSchema
 *
 * @author rhavin
 */
class StringSchema extends AbstractSchema {
	public function __construct($id = null) {
		parent::__construct($id, 'string');
	}
}
